chrome.runtime.onInstalled.addListener(()=>{console.log("NOCAP Extension installed (v1.5.0)!")});chrome.runtime.onMessage.addListener((e,s,n)=>(e.action==="PING"&&n({success:!0}),!0));
